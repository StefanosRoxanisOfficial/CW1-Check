# -*- coding: utf-8 -*-

from cell_based_forward_search import CellBasedForwardSearch
from Queue import PriorityQueue
import math



class greedyPlanner(CellBasedForwardSearch):

    #Construct new planner object
    def __init__(self, title, occupancyGrid):
        CellBasedForwardSearch.__init__(self, title, occupancyGrid)
        self.greedyQueue = PriorityQueue()

    #Euclidean Distance
    def Euclid(self, cell):
        dx = cell.coords[0] - self.goal.coords[0]
        dy = cell.coords[1] - self.goal.coords[1]
        dist = math.sqrt(dx*dx + dy*dy)
        return dist

    # Adding Cell and Distance to Goal tuple to Queue 
    def pushCellOntoQueue(self, cell):
        #dx = cell.coords[0] - self.goal.coords[0]
        #dy = cell.coords[1] - self.goal.coords[1]
        #dist = math.sqrt(dx*dx + dy*dy)
        #print(dist)
        #self.greedyQueue.put((dist,cell))

	#Max Length Of Queue
        queueSize = self.greedyQueue.qsize()
        self.maxQueueSize = max(self.maxQueueSize, queueSize)
	#Adding the tuple to the queue
        self.greedyQueue.put((self.Euclid(cell),cell))

    # Check the queue size is zero
    def isQueueEmpty(self):
        return self.greedyQueue.empty()

    # Simply pull from the front of the list
    def popCellFromQueue(self):
        tuple = self.greedyQueue.get()
        return tuple[1]

    def resolveDuplicate(self, cell, parentCell):
        # Nothing to do in self case
        pass
