# -*- coding: utf-8 -*-
from cell_based_forward_search import CellBasedForwardSearch
import Queue
from Queue import PriorityQueue
import math



class astarPlanner(CellBasedForwardSearch):

    # Construct the new planner object
    def __init__(self, title, occupancyGrid):
        CellBasedForwardSearch.__init__(self, title, occupancyGrid)
        self.astarQueue = PriorityQueue()

        #Determine which heuristic to use
        self.heuristic = 2

        #Determine the weighting of the scaled A* algorithm
        self.weight = 2


#Calculate the L-Stage Additive Cost from any cell to the start. 
    def totalCost(self, cell):
        parentCell = cell.parent 
	pathCost = self.computeLStageAdditiveCost(parentCell, cell) + self.weight*self.heuristicCost(cell)
        #Now we work backwards to the start and add the costs, along that route. 
        #The start position is reached with the LStageAdditiveCost is 0. 
        while (self.computeLStageAdditiveCost(parentCell, cell) != 0):
	    edgeCost = self.computeLStageAdditiveCost(parentCell.parent, parentCell)
            pathCost = pathCost + edgeCost
            parentCell = parentCell.parent
	    
        cell.pathCost = pathCost
        return cell.pathCost

    
    # Adding the totalCost and cell tuple to the PriorityQueue 
    def pushCellOntoQueue(self, cell):
        queueSize = self.astarQueue.qsize()
        self.maxQueueSize = max(self.maxQueueSize, queueSize)
	   #Adding the tuple to the queue
        self.astarQueue.put((self.totalCost(cell),cell))

	#Euclidean Distance
    def euclideanDistance(self, cell):
        dx = cell.coords[0] - self.goal.coords[0]
        dy = cell.coords[1] - self.goal.coords[1]
        dist = math.sqrt(dx*dx + dy*dy)
        return dist

	#Octile Distance
    def octileDistance(self, cell):
        dx = cell.coords[0] - self.goal.coords[0]
        dy = cell.coords[1] - self.goal.coords[1]
        dist = max(abs(dx),abs(dy)) + (math.sqrt(2)-1)*min(abs(dx),abs(dy))
        return dist


	#Manhattan Distance
    def manhattanDistance(self, cell):
        dx = cell.coords[0] - self.goal.coords[0]
        dy = cell.coords[1] - self.goal.coords[1]
        dist = abs(dx) + abs(dy)
        return dist

	#Euclidean Square
    def euclideanSquare(self, cell):
        dx = cell.coords[0] - self.goal.coords[0]
        dy = cell.coords[1] - self.goal.coords[1]
        dist = abs(dx*dx) + abs(dy*dy)
        return dist	


    def heuristicCost(self,cell):

        if self.heuristic == 0:
	    return 50
	elif self.heuristic == 1:
            #Euclidean distance
            return self.euclideanDistance(cell)
        elif self.heuristic == 2:
            #Octile distance
            return self.octileDistance(cell)
        elif self.heuristic == 3:
            #Manhattan distance
            return self.manhattanDistance(cell)
        elif self.heuristic == 4:
	    #Square of Euclidean distance
	    return self.euclideanSquare(cell)

    # Check the queue size is zero
    def isQueueEmpty(self):
        return self.astarQueue.empty()

    # Simply pull from the front of the list
    def popCellFromQueue(self):
        tuple = self.astarQueue.get()
        return tuple[1]


    def resolveDuplicate(self, cell, parentCell):
 	predictedPathCost = parentCell.pathCost + self.computeLStageAdditiveCost(parentCell, cell)
	#self.counter = self.counter + 1
        if predictedPathCost < cell.pathCost:
            #print('duplicate replaced')
            cell.parent = parentCell
            cell.pathCost = predictedPathCost

            queueList = list(self.astarQueue.queue)
            duplicate = [item for item in queueList if item[1] == cell]
	    if duplicate == []:
		pass
	    else:
		    #print('duplicate =') +str(duplicate) 
		    queueList.remove(duplicate[0])
		    
		    self.newQueue = PriorityQueue()
		    
		    for i in queueList:
		        self.newQueue.put(i)

		    self.astarQueue = self.newQueue
		    self.pushCellOntoQueue(cell)

        # Nothing to do in self case
        else:
             pass

