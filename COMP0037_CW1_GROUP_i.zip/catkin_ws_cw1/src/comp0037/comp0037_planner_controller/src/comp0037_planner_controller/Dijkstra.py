# -*- coding: utf-8 -*-

from cell_based_forward_search import CellBasedForwardSearch
from collections import deque
from Queue import PriorityQueue
import math

class dijkstraPlanner(CellBasedForwardSearch):

    # Construct the new planner object
    def __init__(self, title, occupancyGrid):
        CellBasedForwardSearch.__init__(self, title, occupancyGrid)
        self.dijkstraQueue = PriorityQueue()


    #Calculate the L-Stage Additive Cost from any cell to the start. 
    def totalCost(self, cell):
        parentCell = cell.parent 
	pathCost = self.computeLStageAdditiveCost(parentCell, cell)
        #We then work backwards along the route and add costs
        #The start position is reached with the LStageAdditiveCost is 0. 
        while (self.computeLStageAdditiveCost(parentCell, cell) != 0):
	    edgeCost = self.computeLStageAdditiveCost(parentCell.parent, parentCell)
            pathCost = pathCost + edgeCost
            parentCell = parentCell.parent
	    
        cell.pathCost = pathCost
        return cell.pathCost
	

    # Adding the totalCost and cell tuple to the PriorityQueue 
    def pushCellOntoQueue(self, cell):
        queueSize = self.dijkstraQueue.qsize()
        self.maxQueueSize = max(self.maxQueueSize, queueSize)
	   #Adding the tuple to the queue
        self.dijkstraQueue.put((self.totalCost(cell),cell))

    # Check the queue size is zero
    def isQueueEmpty(self):
        return self.dijkstraQueue.empty()

    # Simply pulling from the front of the list
    def popCellFromQueue(self):
        tuple = self.dijkstraQueue.get()
        return tuple[1]

    #Dijkstra's Algorithm: Resolve Duplicates from slides:
    def resolveDuplicate(self, cell, parentCell):
 	predictedPathCost = parentCell.pathCost + self.computeLStageAdditiveCost(parentCell, cell)
	#Can count number of duplicates if desired
	#self.counter = self.counter + 1
        if predictedPathCost < cell.pathCost:
            print('yes')
            cell.parent = parentCell
            cell.pathCost = predictedPathCost

            queueList = list(self.dijkstraQueue.queue)
            duplicate = [item for item in queueList if item[1] == cell]
            queueList.remove(duplicate[0])

            self.newQueue = PriorityQueue()
            
            for i in queueList:
                self.newQueue.put(i)

            self.dijkstraQueue = self.newQueue
            self.pushCellOntoQueue(cell)

        # Nothing to do in self case
        else:
             pass
